import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.mixture import GaussianMixture


class FakeNewsDetector:
    def __init__(self, gmm_model_path, svd_model_path, tfidf_vectorizer_path):
        with open(gmm_model_path, 'rb') as file:
            self.gmm_model = pickle.load(file)

        with open(svd_model_path, 'rb') as file:
            self.svd_model = pickle.load(file)

        with open(tfidf_vectorizer_path, 'rb') as file:
            self.tfidf_vectorizer = pickle.load(file)

    def preprocess_input(self, user_input):
        user_tfidf = self.tfidf_vectorizer.transform([user_input])
        user_svd = self.svd_model.transform(user_tfidf)
        return user_svd

    def predict_label(self, user_svd):
        label = self.gmm_model.predict(user_svd)
        prediction = "fake" if label == 0 else "real"
        return prediction


# Create an instance of FakeNewsDetector
